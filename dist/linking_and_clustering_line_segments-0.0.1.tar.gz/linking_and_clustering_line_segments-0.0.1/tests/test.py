lines["Dike Cluster Length"]
lines['R_Width']

lines['AvgTheta']
lines['AvgRho']
